package com.ihyeongjin.user_domain

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class UserDomainApplicationTests {

	@Test
	fun contextLoads() {
	}

}
